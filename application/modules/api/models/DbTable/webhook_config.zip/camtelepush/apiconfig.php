<?php 
$mainUrl = 'http://cloud.cam-app.com/psiscd.25.8/public/api/telegram/index';
$helpUrl = "{$mainUrl}?url=help";
$aboutUsUrl = "{$mainUrl}?url=aboutUs";
$getInfoUrl = "{$mainUrl}?url=getInfo";
$startBotUrl = "{$mainUrl}?url=startBot";

$sumbitStudentUrl = "{$mainUrl}?url=add";
$removeStudentUrl = "{$mainUrl}?url=remove";


function submitCURL($urlSubmit,$parameters = array()){
    $apiUrl = $urlSubmit;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_POST, count($parameters));
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    
    $resturn = json_decode($result, true);
    return $resturn;
}

function getCurl($getUrl){
   
        $headers = array(
            'Accept: application/json',
            'Content-Type: application/json; charset=utf-8',
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $getUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
		

		if ($err) {
		  return null;
		} else {
			$resturn = json_decode($response, true);
			return $resturn;
		}
}