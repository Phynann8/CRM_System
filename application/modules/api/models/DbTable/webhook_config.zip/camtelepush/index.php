<?php

include 'config.php';
include 'apiconfig.php';


$data = file_get_contents('php://input');


// 	$logFile= "err.json";
//     $log = fopen($logFile, "a");
//     fwrite($log,$data);
//     fclose($log);
$getData = json_decode($data, true);

$userId = $getData['message']['from']['id'];
$firstName = $getData['message']['from']['first_name'];
$lastName = $getData['message']['from']['last_name'];
$userMessage = $getData['message'] ['text'];
$reply_markup="";

$keyboard = [
   
        [
            ["text" => "My Kid(s)"]
        ],
        [
            ["text" => "About Us"],["text" => "Help"]
        ],
    ];
 $reply_markup = json_encode([
        "keyboard" => $keyboard,
        "resize_keyboard" => true,
        "one_time_keyboard" => true
    ]);

$botMessage = "Currenlty unable to connecting to PSIS Chamkar Doung Bot";
if($userMessage == "/start") {
    $botMessage = "Welcome to PSIS Chamkar Doung";
    /*
    $keyboard = [
        [
            ["text" => "Help"]
        ],
        [
            ["text" => "Info"]
        ]
    ];
    $reply_markup = json_encode([
        "keyboard" => $keyboard,
        "resize_keyboard" => true,
        "one_time_keyboard" => true
    ]);
    */
    $sysUrl = "{$startBotUrl}&chatId={$userId}&firstName{$firstName}&lastName{$lastName}";
    $response = getCurl($sysUrl);
    if(!empty($response)){
        if($response["code"]=="SUCCESS"){
            $botMessage = $response["result"];
        }
    }
}else if ($userMessage == "/stop"){
    $botMessage = "Successfully unsubscribe our bot";   

}else if ($userMessage == "/removeall" || $userMessage == "/Removeall" ){    
    $sysUrl = $removeStudentUrl;
    $dataSubmit = array(
        "chatId" => $userId,
        "removeall" =>"1",
        "text" => $userMessage,
    );
    $response = submitCURL($sysUrl,$dataSubmit);
    if(!empty($response)){
        if($response["code"]=="SUCCESS"){
            $botMessage = $response["message"];
        }else{
            $botMessage = $response["message"];
        }
    }
}else if (strpos($userMessage, "/remove") !== false){
    
    $strArray = explode("/remove",$userMessage);
    $studentCode = trim(end($strArray));

    $sysUrl = $removeStudentUrl;
    $dataSubmit = array(
        "chatId" => $userId,
            "studentCode" => $studentCode,
            "text" => $userMessage,
        );
    $response = submitCURL($sysUrl,$dataSubmit);
    if(!empty($response)){
        if($response["code"]=="SUCCESS"){
            $botMessage = $response["message"];
        }else{
            $botMessage = $response["message"];
        }
    }
}else if (strpos($userMessage, "/add") !== false){
    
    $strArray = explode("/add",$userMessage);
    $studentCode = trim(end($strArray));

    $sysUrl = $sumbitStudentUrl;
    $dataSubmit = array(
        "chatId" => $userId,
            "firstName" => $firstName,
            "lastName" => $lastName,
            "studentCode" => $studentCode,
            "text" => $userMessage,
        );
    $response = submitCURL($sysUrl,$dataSubmit);
    if(!empty($response)){
        if($response["code"]=="SUCCESS"){
            $botMessage = $response["message"];
        }else{
            $botMessage = $response["message"];
        }
    }
}else if ($userMessage == "/Aboutus" || $userMessage == "/aboutus"|| $userMessage == "About Us"){
    
    $sysUrl = "{$aboutUsUrl}&chatId={$userId}";
    $response = getCurl($sysUrl);
    if(!empty($response)){
        if($response["code"]=="SUCCESS"){
            $botMessage = $response["result"];
        }
    }
}else if ($userMessage == "/Mykids" || $userMessage == "/mykids"|| $userMessage == "My Kid(s)"){
    $sysUrl = "{$getInfoUrl}&chatId={$userId}";
    $response = getCurl($sysUrl);
    if(!empty($response)){
        if($response["code"]=="SUCCESS"){
            $botMessage = $response["result"];
        }
    }

}else if ($userMessage == "/Help" || $userMessage == "/help" || $userMessage == "Help"){
    $sysUrl = "{$helpUrl}&chatId={$userId}";
    $response = getCurl($sysUrl);
    if(!empty($response)){
        if($response["code"]=="SUCCESS"){
            $botMessage = $response["result"];
        }
    }
}else{
   $botMessage = "Sorry, I don't understand what you mean.";
}


$parameters = array(
    "chat_id" => $userId,
    "text" => $botMessage,
    "parse_mode" => "html",
    "reply_markup" => $reply_markup,
);

$apiUrl = "https://api.telegram.org/bot{$BOT_TOKEN}/sendMessage";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_POST, count($parameters));
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);
curl_close($ch);

echo $result;

