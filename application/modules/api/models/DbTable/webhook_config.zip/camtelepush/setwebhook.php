<?php

include 'config.php';

$webHookUrl = "https://cam-app.com/camtelepush/index.php";

$apiUrl = "https://api.telegram.org/bot{$BOT_TOKEN}/setWebhook?url={$webHookUrl}";

$response = file_get_contents($apiUrl);

echo $response;